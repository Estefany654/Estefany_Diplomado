from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.utils import timezone
from .managers import UsuarioManager
from django.utils.text import slugify
from decimal import Decimal
from django.conf import settings
from django.core.validators import MinValueValidator

class Usuario(AbstractBaseUser, PermissionsMixin):
    ROL_CHOICES = (
        ("ADMIN", "Administrador"),
        ("VENDEDOR", "Vendedor"),
        ("CLIENTE", "Cliente"),
    )

    email = models.EmailField(unique=True, max_length=255)
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=100)
    celular = models.CharField(max_length=20, blank=True)
    rol = models.CharField(max_length=10, choices=ROL_CHOICES, default="CLIENTE")

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)
    
    bloqueado_hasta = models.DateTimeField(null=True, blank=True)  

    objects = UsuarioManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["nombres", "apellidos"]

    def __str__(self):
        return f"{self.email} ({self.rol})"

class Categoria(models.Model):
    nombre = models.CharField(max_length=120, unique=True)
    descripcion = models.TextField(blank=True)
    slug = models.SlugField(max_length=140, unique=True, blank=True)
    activa = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Categoría"
        verbose_name_plural = "Categorías"
        ordering = ["nombre"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nombre)[:140]
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    categoria = models.ForeignKey(Categoria, on_delete=models.PROTECT, related_name="productos")
    nombre = models.CharField(max_length=180)
    descripcion = models.TextField(blank=True)
    precio = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0, message="El precio no puede ser negativo.")]
    )
    stock = models.IntegerField(
        validators=[MinValueValidator(0, message="El stock no puede ser negativo.")]
    )
    activo = models.BooleanField(default=True)
    destacado = models.BooleanField(default=False)
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)


    vendedor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="productos",
        null=True, blank=True)

    class Meta:
        ordering = ["-creado"]

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.nombre)[:180]
            # Evitar choque de slugs básicos (agrega id luego del primer save)
            super().save(*args, **kwargs)
            if not self.slug:
                self.slug = f"{base}-{self.id}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nombre


class ImagenProducto(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="imagenes")
    imagen = models.ImageField(upload_to="productos/")
    principal = models.BooleanField(default=False)
    creado = models.DateTimeField(auto_now_add=True)

    alt_text = models.CharField(max_length=150, blank=True, null=True)     
    orden = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "Imagen de producto"
        verbose_name_plural = "Imágenes de producto"

    def __str__(self):
        return f"Imagen de {self.producto.nombre}"

from django.utils import timezone

class Reserva(models.Model):
    ESTADOS = [
        ("pendiente", "Pendiente"),
        ("confirmada", "Confirmada"),
        ("cancelada", "Cancelada"),
        ("expirada", "Expirada"),
    ]

    cliente = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="reservas")
    estado = models.CharField(max_length=20, choices=ESTADOS, default="pendiente")
    fecha_reserva = models.DateTimeField(default=timezone.now)
    fecha_vencimiento = models.DateTimeField()
    observaciones = models.TextField(blank=True)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        ordering = ["-fecha_reserva"]
        
    def esta_vencida(self):
        return timezone.now() > self.fecha_vencimiento and self.estado == "pendiente"

    def __str__(self):
        return f"Reserva #{self.id} - {self.cliente.email}"

class ReservaDetalle(models.Model):
    reserva = models.ForeignKey(Reserva, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    cantidad = models.PositiveIntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)

    def subtotal(self):
        return self.cantidad * self.precio_unitario

    def __str__(self):
        return f"{self.producto.nombre} x {self.cantidad}"



from decimal import Decimal

class Venta(models.Model):
    cliente = models.ForeignKey(Usuario, on_delete=models.PROTECT, related_name="compras")
    vendedor = models.ForeignKey(Usuario, on_delete=models.PROTECT, related_name="ventas_realizadas")
    reserva = models.OneToOneField(Reserva, on_delete=models.PROTECT, related_name="venta")
    fecha = models.DateTimeField(default=timezone.now)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    reserva = models.ForeignKey(
            Reserva,
            null=True, blank=True,              
            on_delete=models.SET_NULL,          
            related_name="ventas"
        )

    class Meta:
        ordering = ["-fecha"]

    def __str__(self):
        return f"Venta #{self.id} (Reserva #{self.reserva.id}) - {self.cliente.email}"

class VentaDetalle(models.Model):
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE, related_name="detalles")
    producto = models.ForeignKey(Producto, on_delete=models.PROTECT)
    cantidad = models.PositiveIntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)

    def subtotal(self):
        return self.cantidad * self.precio_unitario

    def __str__(self):
        return f"{self.producto.nombre} x {self.cantidad}"

class Reseña(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name="reseñas")
    cliente = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="reseñas")
    puntuacion = models.PositiveSmallIntegerField()  # 1 a 5
    comentario = models.TextField(blank=True)
    fecha = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = ("producto", "cliente")  
        ordering = ["-fecha"]

    def __str__(self):
        return f"Reseña de {self.cliente.email} para {self.producto.nombre} ({self.puntuacion}★)"

from django import forms
from django.utils import timezone

class ReportForm(forms.Form):
    desde = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Desde'
    )
    hasta = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Hasta'
    )

    def clean(self):
        cleaned_data = super().clean()
        desde = cleaned_data.get('desde')
        hasta = cleaned_data.get('hasta')
        hoy = timezone.localdate()

        if hasta and hasta > hoy:
            raise forms.ValidationError({
                'hasta': 'La fecha "Hasta" no puede ser posterior a hoy.'
            })

        if desde and hasta and desde > hasta:
            raise forms.ValidationError({
                'desde': 'La fecha "Desde" debe ser anterior o igual a la fecha "Hasta".'
            })

        return cleaned_data