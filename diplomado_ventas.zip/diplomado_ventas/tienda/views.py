from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404
from .models import Categoria, Producto, Venta
from .models import Reserva, ReservaDetalle
from .forms import RegistroClienteForm, LoginEmailForm
from django.contrib.auth.decorators import user_passes_test
from datetime import timedelta
from django.utils import timezone
from django.db import transaction
from django.db.models import Count, Q
from .models import Usuario, Producto, Categoria, Reserva
from django.views.decorators.http import require_POST
from .forms import ReseñaForm
from .models import Reseña, Producto, VentaDetalle 
from django.db.models import Avg  
from django.contrib.auth.decorators import user_passes_test

def admin_required(view_func):
    return user_passes_test(lambda u: u.is_authenticated and u.rol == "ADMIN")(view_func)


from django.db.models import Avg
from .models import Producto, Categoria, Reseña

def landing(request):
    destacados = (Producto.objects.filter(activo=True, destacado=True)
                  .prefetch_related("imagenes")[:8])
    categorias = Categoria.objects.all()[:6]
    opiniones = (Reseña.objects.select_related("cliente", "producto")
                 .order_by("-fecha"))
    promedio_global = Reseña.objects.aggregate(avg=Avg("puntuacion"))["avg"]
    ctx = {
        "destacados": destacados,
        "categorias": categorias,
        "opiniones": opiniones,
        "promedio_global": promedio_global,
    }
    return render(request, "tienda/landing.html", ctx)
def acerca_de(request):
    return render(request, "tienda/info/acerca.html")


def faq(request):
    return render(request, "tienda/info/faq.html")

def register(request):
    if request.method == "POST":
        form = RegistroClienteForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Cuenta creada. Ya puedes iniciar sesión.")
            return redirect("login")
    else:
        form = RegistroClienteForm()
    return render(request, "tienda/auth/register.html", {"form": form})

def login_view(request):
    if request.method == "POST":
        form = LoginEmailForm(request.POST)
        if form.is_valid():
            user = form.cleaned_data["user"]
            login(request, user)
            if user.rol == "ADMIN":
                 return redirect("admin_dashboard")
            elif user.rol == "VENDEDOR":
                 return redirect("reservas_pendientes")
            else:
                 return redirect("productos_lista")
    else:
        form = LoginEmailForm()
    return render(request, "tienda/auth/login.html", {"form": form})

@login_required
def logout_view(request):
    logout(request)
    messages.info(request, "Sesión cerrada.")
    return redirect("landing")

def productos_lista(request):
    Producto.objects.filter(activo=True, stock__gt=0)
    qs = Producto.objects.filter(activo=True).select_related("categoria").prefetch_related("imagenes")
    categoria_slug = request.GET.get("categoria")
    if categoria_slug:
        qs = qs.filter(categoria__slug=categoria_slug)

    paginator = Paginator(qs, 12) 
    page = request.GET.get("page")
    productos = paginator.get_page(page)

    categorias = Categoria.objects.all().order_by("nombre")
    return render(request, "tienda/productos/lista.html", {
        "productos": productos,
        "categorias": categorias,
        "categoria_slug": categoria_slug,
    })


from django.db.models import Avg
from .models import Reseña, VentaDetalle

def producto_detalle(request, slug):
    producto = get_object_or_404(
        Producto.objects.select_related("categoria").prefetch_related("imagenes"),
        slug=slug, activo=True
    )

    reseñas = Reseña.objects.filter(producto=producto).select_related("cliente")
    promedio = reseñas.aggregate(avg=Avg("puntuacion"))["avg"]

    puede_reseñar = False
    mi_reseña = None

    if request.user.is_authenticated and getattr(request.user, "rol", None) == "CLIENTE":
        # Verificar si el cliente ya compró el producto
        compró = VentaDetalle.objects.filter(
            venta__cliente=request.user,
            producto=producto
        ).exists()
        if compró:
            puede_reseñar = True
            mi_reseña = Reseña.objects.filter(producto=producto, cliente=request.user).first()

    return render(
        request,
        "tienda/productos/detalle.html",
        {
            "producto": producto,
            "reseñas": reseñas,
            "promedio": promedio,
            "puede_reseñar": puede_reseñar,
            "mi_reseña": mi_reseña,
        }
    )

@login_required
def reservar_producto(request, slug):
    producto = get_object_or_404(Producto, slug=slug, activo=True)

     # Solo clientes
    if request.user.rol != "CLIENTE":
        messages.error(request, "Solo los clientes pueden realizar reservas.")
        return redirect("producto_detalle", slug=slug)

    # Bloqueo temporal por abuso
    if request.user.bloqueado_hasta and timezone.now() < request.user.bloqueado_hasta:
        hasta = request.user.bloqueado_hasta.strftime("%d/%m/%Y %H:%M")
        messages.error(request, f"No puedes reservar hasta el {hasta} por múltiples reservas vencidas.")
        return redirect("producto_detalle", slug=slug)

    # Stock
    if producto.stock < 1:
        messages.error(request, "No hay stock disponible para este producto.")
        return redirect("producto_detalle", slug=slug)

    # Límite de reservas activas
    reservas_activas = Reserva.objects.filter(cliente=request.user, estado="pendiente").count()
    if reservas_activas >= 3:
        messages.error(request, "Has alcanzado el límite de 3 reservas activas.")
        return redirect("producto_detalle", slug=slug)

    # Evitar duplicadas del mismo producto
    duplicada = ReservaDetalle.objects.filter(
        reserva__cliente=request.user,
        reserva__estado="pendiente",
        producto=producto
    ).exists()
    if duplicada:
        messages.error(request, "Ya tienes una reserva pendiente de este producto.")
        return redirect("producto_detalle", slug=slug)

    # Crear reserva
    reserva = Reserva.objects.create(
        cliente=request.user,
        fecha_vencimiento=timezone.now() + timedelta(hours=48)
    )
    ReservaDetalle.objects.create(
        reserva=reserva,
        producto=producto,
        cantidad=1,
        precio_unitario=producto.precio
    )
    reserva.total = producto.precio
    reserva.save()

    messages.success(request, f"Has reservado {producto.nombre}. Tienes 48 horas para pagar en tienda.")
    return redirect("mis_reservas")
   

@login_required
def mis_reservas(request):
    _marcar_reservas_vencidas()  #
    reservas = Reserva.objects.filter(cliente=request.user).order_by("-fecha_reserva")
    return render(request, "tienda/reservas/mis_reservas.html", {"reservas": reservas})



# Decorador para verificar si es vendedor o admin
def vendedor_required(view_func):
    return user_passes_test(lambda u: u.is_authenticated and u.rol in ["VENDEDOR", "ADMIN"])(view_func)

@vendedor_required
def reservas_pendientes(request):
    _marcar_reservas_vencidas()
    reservas = Reserva.objects.filter(estado="pendiente").prefetch_related("detalles__producto", "cliente")
    return render(request, "tienda/vendedor/reservas_pendientes.html", {"reservas": reservas})

@vendedor_required
def reservas_confirmadas(request):
    _marcar_reservas_vencidas()  #
    reservas = Reserva.objects.filter(estado="confirmada").prefetch_related("detalles__producto", "cliente")
    return render(request, "tienda/vendedor/reservas_confirmadas.html", {"reservas": reservas})


@vendedor_required
def cancelar_reserva(request, reserva_id):
    reserva = get_object_or_404(Reserva, id=reserva_id, estado="pendiente")
    reserva.estado = "cancelada"
    reserva.save()
    messages.info(request, f"Reserva #{reserva.id} cancelada.")
    return redirect("reservas_pendientes")


@admin_required
def admin_dashboard(request):
    # Métricas de usuarios
    total_usuarios = Usuario.objects.count()
    total_clientes = Usuario.objects.filter(rol="CLIENTE").count()
    total_vendedores = Usuario.objects.filter(rol="VENDEDOR").count()
    total_admins = Usuario.objects.filter(rol="ADMIN").count()

    # Productos
    total_productos = Producto.objects.count()
    stock_bajo = Producto.objects.filter(activo=True, stock__lte=5).order_by("stock")[:10]

    # Reservas por estado
    reservas_por_estado = (
        Reserva.objects.values("estado")
        .annotate(cantidad=Count("id"))
        .order_by()
    )
    # Conteo rápido
    r_pendientes = sum(r["cantidad"] for r in reservas_por_estado if r["estado"] == "pendiente")
    r_confirmadas = sum(r["cantidad"] for r in reservas_por_estado if r["estado"] == "confirmada")
    r_canceladas = sum(r["cantidad"] for r in reservas_por_estado if r["estado"] == "cancelada")
    r_expiradas = sum(r["cantidad"] for r in reservas_por_estado if r["estado"] == "expirada")

    ctx = {
        "total_usuarios": total_usuarios,
        "total_clientes": total_clientes,
        "total_vendedores": total_vendedores,
        "total_admins": total_admins,
        "total_productos": total_productos,
        "stock_bajo": stock_bajo,
        "r_pendientes": r_pendientes,
        "r_confirmadas": r_confirmadas,
        "r_canceladas": r_canceladas,
        "r_expiradas": r_expiradas,
    }
    
    return render(request, "tienda/admin/dashboard.html", ctx)

#Gestión de usuarios

@admin_required
def admin_usuarios_list(request):
    q = request.GET.get("q", "").strip()
    usuarios = Usuario.objects.all().order_by("-date_joined")
    if q:
        usuarios = usuarios.filter(
            Q(email__icontains=q) |
            Q(nombres__icontains=q) |
            Q(apellidos__icontains=q)
        )
    return render(request, "tienda/admin/usuarios_list.html", {"usuarios": usuarios, "q": q})

@admin_required
@require_POST
def admin_usuario_toggle_activo(request, user_id):
    u = Usuario.objects.get(id=user_id)
    u.is_active = not u.is_active
    u.save()
    messages.info(request, f"Usuario {u.email} {'activado' if u.is_active else 'desactivado'}.")
    return redirect("admin_usuarios_list")

@admin_required
@require_POST
def admin_usuario_cambiar_rol(request, user_id):
    nuevo_rol = request.POST.get("rol")
    if nuevo_rol not in ["ADMIN", "VENDEDOR", "CLIENTE"]:
        messages.error(request, "Rol inválido.")
        return redirect("admin_usuarios_list")
    u = Usuario.objects.get(id=user_id)
    u.rol = nuevo_rol
    if nuevo_rol == "ADMIN":
        u.is_staff = True
    u.save()
    messages.success(request, f"Rol de {u.email} cambiado a {nuevo_rol}.")
    return redirect("admin_usuarios_list")

# Gestión rápida de categorías
@admin_required
def admin_categorias(request):
    if request.method == "POST":
        nombre = request.POST.get("nombre", "").strip()
        descripcion = request.POST.get("descripcion", "").strip()
        if not nombre:
            messages.error(request, "El nombre es obligatorio.")
        else:
            if Categoria.objects.filter(nombre__iexact=nombre).exists():
                messages.error(request, "Ya existe una categoría con ese nombre.")
            else:
                Categoria.objects.create(nombre=nombre, descripcion=descripcion)
                messages.success(request, "Categoría creada.")
        return redirect("admin_categorias")

    cats = Categoria.objects.order_by("nombre")
    return render(request, "tienda/admin/categorias.html", {"categorias": cats})


@admin_required
def categoria_edit(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == "POST":
        nombre = request.POST.get("nombre", "").strip()
        descripcion = request.POST.get("descripcion", "").strip()
        if not nombre:
            messages.error(request, "El nombre es obligatorio.")
        else:

            if Categoria.objects.filter(nombre__iexact=nombre).exclude(pk=pk).exists():
                messages.error(request, "Ya existe otra categoría con ese nombre.")
            else:
                categoria.nombre = nombre
                categoria.descripcion = descripcion
                categoria.save()
                messages.success(request, "Categoría actualizada.")
                return redirect("admin_categorias")

    return render(request, "tienda/admin/categoria_edit.html", {"categoria": categoria})


@admin_required
def categoria_delete(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    categoria.activa = False
    categoria.save()
    messages.success(request, "Categoría desactivada.")
    return redirect("admin_categorias")

#Listar reservas
@admin_required
def admin_reservas(request):
    estado = request.GET.get("estado", "").strip()
    reservas = Reserva.objects.all().select_related("cliente").prefetch_related("detalles__producto").order_by("-fecha_reserva")
    if estado in ["pendiente", "confirmada", "cancelada", "expirada"]:
        reservas = reservas.filter(estado=estado)
    return render(request, "tienda/admin/reservas.html", {"reservas": reservas, "estado": estado})

@vendedor_required
def ventas_vendedor(request):
    ventas = (Venta.objects
              .filter(vendedor=request.user)
              .select_related("cliente", "reserva")
              .prefetch_related("detalles__producto")
              .order_by("-fecha"))
    return render(request, "tienda/vendedor/ventas.html", {"ventas": ventas})


@admin_required
def ventas_admin(request):
    q = request.GET.get("q", "").strip()
    ventas = (Venta.objects
              .select_related("cliente", "vendedor", "reserva")
              .prefetch_related("detalles__producto")
              .order_by("-fecha"))
    if q:
        ventas = ventas.filter(
            Q(cliente__email__icontains=q) |
            Q(vendedor__email__icontains=q) |
            Q(reserva__id__icontains=q)
        )
    return render(request, "tienda/admin/ventas.html", {"ventas": ventas, "q": q})


from django.db.models import Prefetch

@login_required
def mis_compras(request):
    if request.user.rol != "CLIENTE":
        messages.error(request, "Acceso no autorizado.")
        return redirect("landing")

    compras = (
        Venta.objects
        .filter(cliente=request.user)
        .select_related("reserva")
        .prefetch_related(
            Prefetch("detalles", queryset=VentaDetalle.objects.select_related("producto"))
        )
        .order_by("-fecha")
    )

    reseñados_ids = set(
        Reseña.objects.filter(cliente=request.user).values_list("producto_id", flat=True)
    )

    return render(
        request,
        "tienda/ventas/mis_compras.html",
        {"compras": compras, "reseñados_ids": reseñados_ids},
    )

@login_required
def agregar_reseña(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)

    if request.user.rol != "CLIENTE":
        messages.error(request, "Solo los clientes pueden dejar reseñas.")
        return redirect("productos_lista")

    compró = VentaDetalle.objects.filter(
        venta__cliente=request.user,
        producto=producto
    ).exists()

    if not compró:
        messages.error(request, "Solo puedes reseñar productos que hayas comprado.")
        return redirect("productos_lista")

    reseña_existente = Reseña.objects.filter(producto=producto, cliente=request.user).first()

    if request.method == "POST":
        form = ReseñaForm(request.POST, instance=reseña_existente)
        if form.is_valid():
            nueva_reseña = form.save(commit=False)
            nueva_reseña.producto = producto
            nueva_reseña.cliente = request.user
            nueva_reseña.save()
            messages.success(request, "Reseña guardada correctamente.")
            return redirect("producto_detalle", slug=producto.slug)
    else:
        form = ReseñaForm(instance=reseña_existente)

    return render(request, "tienda/reseñas/agregar_reseña.html", {"form": form, "producto": producto})


def is_admin(u): 
    return u.is_authenticated and (getattr(u, "rol", "") == "ADMIN" or u.is_superuser or u.is_staff)

def is_vendedor(u): 
    return u.is_authenticated and getattr(u, "rol", "") == "VENDEDOR"


# ============== ADMIN · PRODUCTOS =================

from django.db.models import Q
from django.db.models.functions import Lower
from django.core.paginator import Paginator, EmptyPage
from django.contrib.auth.decorators import login_required, user_passes_test

# Lista de productos para ADMIN
@login_required
@user_passes_test(is_admin)
def admin_productos_list(request):
    q = request.GET.get("q", "").strip()
    estado = request.GET.get("estado", "").strip()  # "", "activos", "archivados"
    page = request.GET.get("page", 1)

    qs = (Producto.objects
          .select_related("categoria", "vendedor")
          .all())

    if q:
        qs = qs.filter(
            Q(nombre__icontains=q) |
            Q(descripcion__icontains=q) |
            Q(categoria__nombre__icontains=q)
        )

    if estado == "activos":
        qs = qs.filter(activo=True)
    elif estado == "archivados":
        qs = qs.filter(activo=False)

    # orden estable por nombre
    qs = qs.order_by(Lower("nombre").asc())

    paginator = Paginator(qs, 20)
    try:
        page_obj = paginator.get_page(page)
    except EmptyPage:
        page_obj = paginator.get_page(1)

    return render(request, "tienda/admin/productos_list.html", {
        "productos": page_obj.object_list,
        "page_obj": page_obj,
        "q": q,
    })

from .forms import AdminProductoForm
@login_required
@user_passes_test(is_admin)
def admin_producto_crear(request):
    if request.method == "POST":
        form = AdminProductoForm(request.POST)
        formset = ImagenFormSet(request.POST, request.FILES, instance=Producto(), prefix="imgs")
        if form.is_valid() and formset.is_valid():
            producto = form.save(commit=False)
            producto.save()
            formset.instance = producto
            formset.save()
            if producto.imagenes.exists() and not producto.imagenes.filter(principal=True).exists():
                img = producto.imagenes.first()
                img.principal = True
                img.save()
            messages.success(request, "Producto creado correctamente.")
            return redirect("admin_productos_list")
        else:
            messages.error(request, "Revisa los errores del formulario.")
    else:
        form = AdminProductoForm()
        formset = ImagenFormSet(instance=Producto(), prefix="imgs")
    return render(request, "tienda/admin/productos_form.html", {
        "form": form,
        "formset": formset,
        "modo": "crear",
    })

@login_required
@user_passes_test(is_admin)
def admin_producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == "POST":
        form = AdminProductoForm(request.POST, instance=producto)
        formset = ImagenFormSet(request.POST, request.FILES, instance=producto, prefix="imgs")
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            if producto.imagenes.exists() and not producto.imagenes.filter(principal=True).exists():
                img = producto.imagenes.first()
                img.principal = True
                img.save()
            messages.success(request, "Producto actualizado correctamente.")
            return redirect("admin_productos_list")
        else:
            messages.error(request, "Revisa los errores del formulario.")
    else:
        form = AdminProductoForm(instance=producto)
        formset = ImagenFormSet(instance=producto, prefix="imgs")
    return render(request, "tienda/admin/productos_form.html", {
        "form": form,
        "formset": formset,
        "modo": "editar",
        "producto": producto,
    })


@login_required
@user_passes_test(lambda u: u.is_authenticated and getattr(u, "rol", "") == "ADMIN")
def admin_producto_eliminar(request, pk):

    producto = get_object_or_404(Producto, pk=pk)

    if request.method != "POST":
        
        return redirect("admin_productos_list")

    # ¿Tiene ventas o reservas?
    tiene_reservas = ReservaDetalle.objects.filter(producto=producto).exists()
    tiene_ventas = VentaDetalle.objects.filter(producto=producto).exists()

    if tiene_reservas or tiene_ventas:
        messages.error(
            request,
            "No puedes eliminar este producto porque tiene movimientos (reservas o ventas)."
        )
        return redirect("admin_productos_list")

    # Si no tiene movimientos, se elimina
    nombre = producto.nombre
    producto.delete()
    messages.success(request, f'Producto "{nombre}" eliminado correctamente.')
    return redirect("admin_productos_list")


from .forms import ImagenFormSet 

@login_required
@user_passes_test(lambda u: u.is_authenticated and getattr(u, "rol", "") == "ADMIN")
def admin_producto_imagenes(request, pk):
    producto = get_object_or_404(Producto, pk=pk)

    if request.method == "POST":
        formset = ImagenFormSet(request.POST, request.FILES, instance=producto, prefix="imgs")
        if formset.is_valid():
            principales = [
                f for f in formset.forms
                if f.cleaned_data and not f.cleaned_data.get("DELETE") and f.cleaned_data.get("principal")
            ]
            if len(principales) > 1:
                messages.error(request, "Solo una imagen puede marcarse como principal.")
            else:
                formset.save()
                messages.success(request, "Imágenes actualizadas correctamente.")
                return redirect("admin_producto_imagenes", pk=producto.pk)
        else:
            messages.error(request, "Revisa los errores en el formulario.")
    else:
        formset = ImagenFormSet(instance=producto, prefix="imgs")
    return render(
        request,
        "tienda/admin/productos_imagenes.html",  
        {"producto": producto, "formset": formset}
    )

@login_required
@user_passes_test(is_admin)
def admin_producto_archivar(request, pk):
    obj = get_object_or_404(Producto, pk=pk)
    obj.activo = False
    obj.save(update_fields=["activo"])
    messages.success(request, "Producto archivado.")
    return redirect("admin_productos_list")

@login_required
@user_passes_test(is_admin)
def admin_producto_activar(request, pk):
    obj = get_object_or_404(Producto, pk=pk)
    obj.activo = True
    obj.save(update_fields=["activo"])
    messages.success(request, "Producto activado.")
    return redirect("admin_productos_list")

# ============ VENDEDOR · EDICIÓN LIMITADA + IMÁGENES ============
from .forms import VendedorProductoForm, ImagenFormSet
from .forms import ImagenProductoFormSet
@login_required
@user_passes_test(is_vendedor)
def vendedor_producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)

    PREFIX = "imgs" 

    if request.method == "POST":
        form = VendedorProductoForm(request.POST, request.FILES, instance=producto)
        formset = ImagenProductoFormSet(request.POST, request.FILES, instance=producto, prefix=PREFIX)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Cambios guardados correctamente.")
            return redirect("vendedor_productos")
        else:
            messages.error(request, "Revisa los errores del formulario.")
    else:
        form = VendedorProductoForm(instance=producto)
        formset = ImagenProductoFormSet(instance=producto, prefix=PREFIX)

    return render(
        request,
        "tienda/vendedor/producto_edit.html",
        {"producto": producto, "form": form, "formset": formset, "prefix": PREFIX},
    )

@login_required
@user_passes_test(is_vendedor)
def vendedor_productos(request):
    q = request.GET.get("q", "").strip()
    productos = (Producto.objects
                 .select_related("categoria")
                 .order_by("-id"))

    if q:
        productos = productos.filter(
            Q(nombre__icontains=q) |
            Q(descripcion__icontains=q) |
            Q(categoria__nombre__icontains=q)
        )
    from django.core.paginator import Paginator
    page_obj = Paginator(productos, 20).get_page(request.GET.get("page"))

    return render(request, "tienda/vendedor/productos_list.html", {
        "productos": page_obj.object_list,
        "page_obj": page_obj,
        "q": q,
    })

@login_required
@user_passes_test(is_vendedor)
def vendedor_producto_imagenes(request, pk):

    obj = get_object_or_404(Producto, pk=pk)
    if obj.vendedor_id and obj.vendedor_id != request.user.id:
        messages.error(request, "No puedes gestionar imágenes de otro vendedor.")
        return redirect("reservas_pendientes")

    if request.method == "POST":
        formset = ImagenProductoFormSet(request.POST, request.FILES, instance=obj)
        if formset.is_valid():
            formset.save()
            messages.success(request, "Imágenes actualizadas.")
            return redirect("reservas_pendientes")
        messages.error(request, "Corrige los errores en imágenes.")
    else:
        formset = ImagenProductoFormSet(instance=obj)

    return render(request, "tienda/vendedor/producto_imagenes.html", {"obj": obj, "formset": formset})


# ============== CONFIRMAR PAGO (stock seguro) ===================
@vendedor_required
@transaction.atomic
def confirmar_pago(request, reserva_id):
    
    reserva = get_object_or_404(
        Reserva.objects.prefetch_related("detalles__producto", "cliente"),
        pk=reserva_id
    )

    if reserva.estado.lower() != "pendiente":
        messages.error(request, f"La reserva no está pendiente (estado actual: {reserva.estado}).")
        return redirect("reservas_pendientes")

    if reserva.fecha_vencimiento < timezone.now():
        reserva.estado = "expirada"
        reserva.save(update_fields=["estado"])
        messages.error(request, "La reserva ya venció. No puede confirmarse.")
        return redirect("reservas_pendientes")

    for d in reserva.detalles.all():
        updated = (Producto.objects
                   .select_for_update()
                   .filter(pk=d.producto_id, stock__gte=d.cantidad)
                   .update(stock=F("stock") - d.cantidad))
        if not updated:
            messages.error(request, f"Stock insuficiente para {d.producto.nombre}.")
            return redirect("reservas_pendientes")

    reserva.estado = "confirmada"
    reserva.save(update_fields=["estado"])

    venta = Venta.objects.create(
        cliente=reserva.cliente,
        vendedor=request.user,
        reserva=reserva,
        total=reserva.total
    )
    for d in reserva.detalles.all():
        VentaDetalle.objects.create(
            venta=venta,
            producto=d.producto,
            cantidad=d.cantidad,
            precio_unitario=d.precio_unitario
        )

    messages.success(request, f"Reserva #{reserva.id} confirmada. Venta #{venta.id} creada.")
    return redirect("reservas_pendientes")

from decimal import Decimal
import json
from django.core.serializers.json import DjangoJSONEncoder
from .forms import VentaCrearForm, VentaDetalleFormSet

def is_vendedor(u):
    return u.is_authenticated and getattr(u, "rol", "") == "VENDEDOR"

@login_required
@user_passes_test(is_vendedor)
@transaction.atomic
def vendedor_venta_nueva(request):
    PREFIX = "items"

    if request.method == "POST":
        form = VentaCrearForm(request.POST)
        formset = VentaDetalleFormSet(request.POST, prefix=PREFIX)

        if form.is_valid() and formset.is_valid():
            venta = form.save(commit=False)
            venta.vendedor = request.user
            venta.reserva = None       
            venta.total = Decimal("0")
            venta.save()

            cantidades = {}
            lineas = []
            for f in formset:
                cd = getattr(f, "cleaned_data", {})
                if not cd or cd.get("DELETE") or not cd.get("producto"):
                    continue
                prod = cd["producto"]
                qty = cd.get("cantidad") or 1
                price = cd.get("precio_unitario") or prod.precio
                lineas.append((prod, qty, price))
                cantidades[prod.pk] = cantidades.get(prod.pk, 0) + qty

            for pk, qty in cantidades.items():
                updated = (Producto.objects
                           .select_for_update()
                           .filter(pk=pk, stock__gte=qty)
                           .update(stock=F("stock") - qty))
                if not updated:
                    messages.error(request, f"Stock insuficiente para «{Producto.objects.get(pk=pk).nombre}».")
                    # La transacción se revierte por @atomic
                    return redirect("vendedor_venta_nueva")

            # Detalles + total
            total = Decimal("0")
            for prod, qty, price in lineas:
                VentaDetalle.objects.create(
                    venta=venta, producto=prod, cantidad=qty, precio_unitario=price
                )
                total += (price * qty)

            venta.total = total
            venta.save(update_fields=["total"])

            messages.success(request, f"Venta #{venta.id} registrada correctamente.")
            return redirect("ventas_vendedor")
        else:
            messages.error(request, "Corrige los errores del formulario.")
    else:
        form = VentaCrearForm()
        formset = VentaDetalleFormSet(prefix=PREFIX)

    # Mapa de productos para JS (id → precio, nombre)
    productos_qs = Producto.objects.filter(activo=True).values("id", "precio", "nombre")
    productos_map = {p["id"]: {"precio": float(p["precio"]), "nombre": p["nombre"]} for p in productos_qs}

    return render(
        request,
        "tienda/vendedor/venta_nueva.html",
        {
            "form": form,
            "formset": formset,
            "prefix": PREFIX,
            "productos_map_json": json.dumps(productos_map, cls=DjangoJSONEncoder),
        },
    )

from django.db.models import Sum, Count, F
from django.db.models.functions import TruncMonth
from django.http import HttpResponse
from datetime import datetime, timedelta
import csv

def is_admin(u):
    return u.is_authenticated and (getattr(u, "rol", "") == "ADMIN" or u.is_staff or u.is_superuser)

from .forms import ReportForm

@login_required
@user_passes_test(is_admin)
def admin_reportes(request):
    hoy = timezone.localdate()
    form = ReportForm(request.GET or None)

    default_desde = hoy - timedelta(days=90)
    default_hasta = hoy

    if form.is_valid():
        desde = form.cleaned_data.get('desde') or default_desde
        hasta = form.cleaned_data.get('hasta') or default_hasta
    else:
        desde = default_desde
        hasta = default_hasta

    # Normaliza fechas para incluir el día completo
    desde_dt = datetime.combine(desde, datetime.min.time(), tzinfo=timezone.get_current_timezone())
    hasta_dt = datetime.combine(hasta, datetime.max.time(), tzinfo=timezone.get_current_timezone())

    ventas = (Venta.objects
              .filter(fecha__range=[desde_dt, hasta_dt])
              .select_related("vendedor", "cliente"))

    # KPIs
    total_ingresos = ventas.aggregate(s=Sum("total"))["s"] or 0
    num_ventas = ventas.count()
    ticket_prom = (total_ingresos / num_ventas) if num_ventas else 0

    # Ingresos por mes (serie)
    serie_mensual = (ventas
                     .annotate(mes=TruncMonth("fecha"))
                     .values("mes")
                     .annotate(ingresos=Sum("total"), ventas=Count("id"))
                     .order_by("mes"))

    # Top categorías (por importe)
    detalles = (VentaDetalle.objects
                .filter(venta__in=ventas)
                .select_related("producto__categoria"))

    top_categorias = (detalles
                      .values(nombre=F("producto__categoria__nombre"))
                      .annotate(importe=Sum(F("precio_unitario") * F("cantidad")),
                                unidades=Sum("cantidad"))
                      .order_by("-importe")[:10])

    # Solo “Accesorios” (si existe)
    accesorios = (detalles
                  .filter(producto__categoria__nombre__iexact="Accesorios")
                  .aggregate(importe=Sum(F("precio_unitario") * F("cantidad")),
                             unidades=Sum("cantidad")))

    # Top productos
    top_productos = (detalles
                     .values(nombre=F("producto__nombre"))
                     .annotate(importe=Sum(F("precio_unitario") * F("cantidad")),
                               unidades=Sum("cantidad"))
                     .order_by("-importe")[:10])

    # Top vendedores
    top_vendedores = (ventas
                      .values(nombre=F("vendedor__email"))  # Cambia a 'nombres' si tienes ese campo
                      .annotate(importe=Sum("total"), ventas=Count("id"))
                      .order_by("-importe")[:10])

    ctx = {
        "form": form,
        "desde": desde,
        "hasta": hasta,
        "total_ingresos": total_ingresos,
        "num_ventas": num_ventas,
        "ticket_prom": ticket_prom,
        "serie_mensual": serie_mensual,
        "top_categorias": top_categorias,
        "top_productos": top_productos,
        "top_vendedores": top_vendedores,
        "accesorios": accesorios,
    }
    return render(request, "tienda/admin/reportes.html", ctx)

@login_required
@user_passes_test(is_admin)
def admin_reportes_csv(request):
    from .models import Venta, VentaDetalle

    tipo = request.GET.get("tipo", "mensual")  # mensual | categorias | productos | vendedores
    df = request.GET.get("desde", "")
    hf = request.GET.get("hasta", "")

    hoy = timezone.localdate()
    try:
        desde = datetime.strptime(df, "%Y-%m-%d").date() if df else (hoy - timedelta(days=90))
    except ValueError:
        desde = hoy - timedelta(days=90)
    try:
        hasta = datetime.strptime(hf, "%Y-%m-%d").date() if hf else hoy
    except ValueError:
        hasta = hoy
    desde_dt = datetime.combine(desde, datetime.min.time(), tzinfo=timezone.get_current_timezone())
    hasta_dt = datetime.combine(hasta, datetime.max.time(), tzinfo=timezone.get_current_timezone())

    ventas = Venta.objects.filter(fecha__range=[desde_dt, hasta_dt])

    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="reporte_{tipo}_{desde}_{hasta}.csv"'
    writer = csv.writer(response)
    writer.writerow(["Rango", str(desde), str(hasta)])

    if tipo == "mensual":
        writer.writerow(["Mes", "Ingresos", "Nº Ventas"])
        qs = (ventas.annotate(mes=TruncMonth("fecha"))
                    .values("mes")
                    .annotate(ingresos=Sum("total"), ventas=Count("id"))
                    .order_by("mes"))
        for r in qs:
            writer.writerow([r["mes"].date(), r["ingresos"] or 0, r["ventas"]])

    elif tipo == "categorias":
        writer.writerow(["Categoría", "Importe", "Unidades"])
        det = VentaDetalle.objects.filter(venta__in=ventas)
        qs = (det.values("producto__categoria__nombre")
                 .annotate(importe=Sum(F("precio_unitario")*F("cantidad")),
                           unidades=Sum("cantidad"))
                 .order_by("-importe"))
        for r in qs:
            writer.writerow([r["producto__categoria__nombre"] or "-", r["importe"] or 0, r["unidades"] or 0])

    elif tipo == "productos":
        writer.writerow(["Producto", "Importe", "Unidades"])
        det = VentaDetalle.objects.filter(venta__in=ventas)
        qs = (det.values("producto__nombre")
                 .annotate(importe=Sum(F("precio_unitario")*F("cantidad")),
                           unidades=Sum("cantidad"))
                 .order_by("-importe"))
        for r in qs:
            writer.writerow([r["producto__nombre"], r["importe"] or 0, r["unidades"] or 0])

    elif tipo == "vendedores":
        writer.writerow(["Vendedor", "Importe", "Nº Ventas"])
        qs = (ventas.values("vendedor__email")
                    .annotate(importe=Sum("total"), ventas=Count("id"))
                    .order_by("-importe"))
        for r in qs:
            writer.writerow([r["vendedor__email"] or "-", r["importe"] or 0, r["ventas"]])

    else:
        writer.writerow(["Tipo no soportado"])
    return response


def _marcar_reservas_vencidas():
    """
    Pasa a 'expirada' todas las reservas 'pendiente' cuyo vencimiento ya pasó.
    """
    ahora = timezone.now()
    (Reserva.objects
           .filter(estado__iexact="pendiente", fecha_vencimiento__lt=ahora)
           .update(estado="expirada"))
