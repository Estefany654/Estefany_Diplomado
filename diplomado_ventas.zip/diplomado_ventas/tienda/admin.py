from django.contrib import admin
from .models import Usuario, Categoria, Producto, ImagenProducto
from .models import Venta, VentaDetalle
from .models import Reseña

@admin.register(Usuario)
class UsuarioAdmin(admin.ModelAdmin):
    list_display = ("email", "nombres", "apellidos", "rol", "is_active", "is_staff", "date_joined")
    list_filter = ("rol", "is_active", "is_staff")
    search_fields = ("email", "nombres", "apellidos")
    ordering = ("-date_joined",)

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ("nombre", "slug")
    prepopulated_fields = {"slug": ("nombre",)}
    search_fields = ("nombre",)

class ImagenProductoInline(admin.TabularInline):
    model = ImagenProducto
    extra = 1

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "categoria", "precio", "stock", "activo", "destacado", "slug")
    list_filter = ("categoria", "activo", "destacado")
    search_fields = ("nombre", "descripcion")
    inlines = [ImagenProductoInline]
    prepopulated_fields = {"slug": ("nombre",)}

@admin.register(ImagenProducto)
class ImagenProductoAdmin(admin.ModelAdmin):
    list_display = ("producto", "principal", "creado")
    list_filter = ("principal",)



class VentaDetalleInline(admin.TabularInline):
    model = VentaDetalle
    extra = 0
    readonly_fields = ("producto", "cantidad", "precio_unitario")

@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ("id", "cliente", "vendedor", "fecha", "total")
    date_hierarchy = "fecha"
    inlines = [VentaDetalleInline]

@admin.register(Reseña)
class ReseñaAdmin(admin.ModelAdmin):
    list_display = ("producto", "cliente", "puntuacion", "fecha")
    search_fields = ("producto__nombre", "cliente__email")
    list_filter = ("puntuacion", "fecha")
