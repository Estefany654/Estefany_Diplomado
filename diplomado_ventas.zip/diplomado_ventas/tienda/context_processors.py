def rol_context(request):
    user = request.user
    return {
        "is_admin": user.is_authenticated and user.rol == "ADMIN",
        "is_vendedor": user.is_authenticated and user.rol == "VENDEDOR",
        "is_cliente": user.is_authenticated and user.rol == "CLIENTE",
    }
