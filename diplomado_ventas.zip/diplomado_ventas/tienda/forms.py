from django import forms
from django.contrib.auth import authenticate
from .models import Usuario
from .models import Reseña
from .models import Producto

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ["nombre", "categoria", "precio", "stock", "descripcion"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "w-full", "placeholder": "Nombre"}),
            "precio": forms.NumberInput(attrs={"step": "0.01", "class": "w-full"}),
            "stock": forms.NumberInput(attrs={"step": "1", "class": "w-full"}),
            "descripcion": forms.Textarea(attrs={"rows": 3, "class": "w-full"}),
        }
    def clean_precio(self):
        precio = self.cleaned_data.get('precio')
        if precio is not None and precio < 0:
            raise forms.ValidationError('El precio no puede ser negativo.')
        return precio

    def clean_stock(self):
        stock = self.cleaned_data.get('stock')
        if stock is not None and stock < 0:
            raise forms.ValidationError('El stock no puede ser negativo.')
        return stock
    

from django import forms
from django.core.validators import RegexValidator
from django.contrib.auth.password_validation import validate_password
from .models import Usuario 

solo_letras = RegexValidator(
    regex=r"^[A-Za-zÁÉÍÓÚáéíóúÑñÜü\s'-]+$",
    message="Solo se permiten letras, espacios y ' - ."
)

solo_8_digitos = RegexValidator(
    regex=r"^\d{8}$",
    message="El celular debe tener exactamente 8 dígitos numéricos."
)

class RegistroClienteForm(forms.ModelForm):
    password1 = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(attrs={
            "class": "w-full border rounded p-2",
            "placeholder": "••••••••",
            "autocomplete": "new-password"
        })
    )
    password2 = forms.CharField(
        label="Confirmar contraseña",
        widget=forms.PasswordInput(attrs={
            "class": "w-full border rounded p-2",
            "placeholder": "Repite la contraseña",
            "autocomplete": "new-password"
        })
    )

    class Meta:
        model = Usuario
        fields = ("nombres", "apellidos", "email", "celular")
        widgets = {
            "nombres": forms.TextInput(attrs={
                "class": "w-full border rounded p-2",
                "placeholder": "Tus nombres",
                "autocomplete": "given-name",
                # ayuda frontend
                "pattern": r"[A-Za-zÁÉÍÓÚáéíóúÑñÜü\s'-]+",
                "inputmode": "text"
            }),
            "apellidos": forms.TextInput(attrs={
                "class": "w-full border rounded p-2",
                "placeholder": "Tus apellidos",
                "autocomplete": "family-name",
                "pattern": r"[A-Za-zÁÉÍÓÚáéíóúÑñÜü\s'-]+",
                "inputmode": "text"
            }),
            "email": forms.EmailInput(attrs={
                "class": "w-full border rounded p-2",
                "placeholder": "tu@email.com",
                "autocomplete": "email"
            }),
            "celular": forms.TextInput(attrs={
                "class": "w-full border rounded p-2",
                "placeholder": "78451236",
                "autocomplete": "tel-national",
                # ayuda frontend
                "pattern": r"\d{8}",
                "inputmode": "numeric",
                "maxlength": "8"
            }),
        }

    def clean_nombres(self):
        v = (self.cleaned_data.get("nombres") or "").strip()
        solo_letras(v)
        return v

    def clean_apellidos(self):
        v = (self.cleaned_data.get("apellidos") or "").strip()
        solo_letras(v)
        return v

    def clean_email(self):
        email = (self.cleaned_data.get("email") or "").lower().strip()
        if Usuario.objects.filter(email=email).exists():
            raise forms.ValidationError("Ya existe una cuenta con este email.")
        return email

    def clean_celular(self):
        cel = (self.cleaned_data.get("celular") or "").strip()
        # Normaliza (por si intentan guiones o espacios)
        cel = "".join(ch for ch in cel if ch.isdigit())
        solo_8_digitos(cel)  # asegura 8 dígitos
        return cel

    def clean(self):
        cleaned = super().clean()
        p1 = cleaned.get("password1")
        p2 = cleaned.get("password2")

        if p1 and p2 and p1 != p2:
            self.add_error("password2", "Las contraseñas no coinciden.")

        if p1:
            user_probe = Usuario(
                email=cleaned.get("email", ""),
                nombres=cleaned.get("nombres", ""),
                apellidos=cleaned.get("apellidos", "")
            )
            validate_password(p1, user=user_probe)

        return cleaned

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"].lower()
        user.rol = "CLIENTE"
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user

# ---------- LOGIN ----------
class LoginEmailForm(forms.Form):
    email = forms.EmailField(
        label="Email",
        widget=forms.EmailInput(attrs={"class": "w-full border rounded p-2"})
    )
    password = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(attrs={"class": "w-full border rounded p-2"})
    )

    def clean(self):
        cleaned = super().clean()
        email = (cleaned.get("email") or "").lower()
        password = cleaned.get("password")

        if email and password:
            user = authenticate(username=email, password=password)
            if user is None:
                raise forms.ValidationError("Email o contraseña incorrectos.")
            if not user.is_active:
                raise forms.ValidationError("La cuenta está inactiva.")
            cleaned["user"] = user

        return cleaned

#------Formulario de Reseña----------
from django import forms
from .models import Reseña

class ReseñaForm(forms.ModelForm):
    class Meta:
        model = Reseña
        fields = ["puntuacion", "comentario"]
        widgets = {
            "puntuacion": forms.NumberInput(attrs={
                "min": 1, "max": 5,
                "class": "w-full border rounded px-3 py-2"
            }),
            "comentario": forms.Textarea(attrs={
                "rows": 4,
                "class": "w-full border rounded px-3 py-2"
            }),
        }

#----------Crud Productos-----------#
from django.forms import inlineformset_factory
from .models import Producto, ImagenProducto


class AdminProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ["categoria", "nombre", "descripcion", "precio", "stock", "activo", "destacado"]
        widgets = {
            "categoria": forms.Select(attrs={"class": "w-full rounded-xl border px-3 py-2"}),
            "nombre": forms.TextInput(attrs={"class": "w-full rounded-xl border px-3 py-2"}),
            "descripcion": forms.Textarea(attrs={"rows": 4, "class": "w-full rounded-xl border px-3 py-2"}),
            "precio": forms.NumberInput(attrs={"step": "0.01",'min': '0', "class": "w-full rounded-xl border px-3 py-2"}),
            "stock": forms.NumberInput(attrs={"class": "w-full rounded-xl border px-3 py-2",'min': '0'}),
            "activo": forms.CheckboxInput(attrs={"class": "h-4 w-4"}),
            "destacado": forms.CheckboxInput(attrs={"class": "h-4 w-4"}),
        }
        def clean_precio(self):
            precio = self.cleaned_data.get('precio')
            if precio is not None and precio < 0:
                raise forms.ValidationError('El precio no puede ser negativo.')
            return precio

        def clean_stock(self):
            stock = self.cleaned_data.get('stock')
            if stock is not None and stock < 0:
                raise forms.ValidationError('El stock no puede ser negativo.')
            return stock
    

class VendedorProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ["nombre", "descripcion", "destacado", "categoria"]
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "w-full"}),
            "descripcion": forms.Textarea(attrs={"rows": 3, "class": "w-full"}),
        }
ImagenFormSet = forms.inlineformset_factory(
    Producto,
    ImagenProducto,
    fields=('imagen', 'principal', 'orden'),
    extra=1,
    can_delete=True,
    widgets={
        'imagen': forms.FileInput(attrs={'class': 'form-group'}),
        'principal': forms.CheckboxInput(attrs={'class': 'checkbox-group'}),
        'orden': forms.NumberInput(attrs={'class': 'form-group', 'min': '0'}),
    }
)


class ImagenProductoForm(forms.ModelForm):
    class Meta:
        model = ImagenProducto
        fields = ["imagen", "orden", "principal"]
        exclude = ["alt_text"]
        widgets = {
            "orden": forms.NumberInput(attrs={"class": "w-full rounded-xl border px-3 py-2"}),
            "principal": forms.CheckboxInput(attrs={"class": "h-4 w-4"}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if self.instance and self.instance.pk:
            self.fields["imagen"].required = False

ImagenFormSet = forms.inlineformset_factory(
    Producto,
    ImagenProducto,
    fields=('imagen', 'principal'),
    extra=1,
    can_delete=True,
    widgets={
        'imagen': forms.FileInput(attrs={'class': 'control'}),
        'principal': forms.CheckboxInput(),
    }
)
from django.forms import inlineformset_factory, BaseInlineFormSet

class BaseImagenFormSet(BaseInlineFormSet):
    def clean(self):
        super().clean()
        principales = 0
        for form in self.forms:
            if not hasattr(form, "cleaned_data"):
                continue
            if form.cleaned_data.get("DELETE"):
                continue
            if form.cleaned_data.get("principal"):
                principales += 1
        if principales > 1:
            raise forms.ValidationError("Solo una imagen puede marcarse como principal.")
        
ImagenProductoFormSet = inlineformset_factory(
    parent_model=Producto,
    model=ImagenProducto,
    form=ImagenProductoForm,
    formset=BaseImagenFormSet,
    fields=["imagen", "alt_text", "orden", "principal"],
    extra=2,              
    can_delete=True
)

#vendedor registra venta

from decimal import Decimal
from django import forms
from django.forms import inlineformset_factory, BaseInlineFormSet
from .models import Usuario, Venta, VentaDetalle, Producto

class ClienteChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        full = f"{(obj.nombres or '').strip()} {(obj.apellidos or '').strip()}".strip()
        return full or obj.email
    
class VentaCrearForm(forms.ModelForm):
    cliente = forms.ModelChoiceField(
        queryset=Usuario.objects.filter(rol="CLIENTE", is_active=True).order_by("email"),
        label="Cliente",
    )

    class Meta:
        model = Venta
        fields = ["cliente"]  

class VentaDetalleForm(forms.ModelForm):
    class Meta:
        model = VentaDetalle
        fields = ["producto", "cantidad", "precio_unitario"]
        widgets = {
            "cantidad": forms.NumberInput(attrs={"min": 1}),
        }

class BaseVentaDetalleFormset(BaseInlineFormSet):
    def clean(self):
        super().clean()
        activos = 0
        for f in self.forms:
            if not hasattr(f, "cleaned_data"):
                continue
            if f.cleaned_data.get("DELETE"):
                continue
            if not f.cleaned_data.get("producto"):
                continue
            activos += 1

            if not f.cleaned_data.get("precio_unitario"):
                prod = f.cleaned_data["producto"]
                f.cleaned_data["precio_unitario"] = prod.precio

        if activos == 0:
            raise forms.ValidationError("Agrega al menos un producto a la venta.")

VentaDetalleFormSet = inlineformset_factory(
    parent_model=Venta,
    model=VentaDetalle,
    form=VentaDetalleForm,
    formset=BaseVentaDetalleFormset,
    fields=["producto", "cantidad", "precio_unitario"],
    extra=1,
    can_delete=True,
)


from django import forms
from django.utils import timezone

class ReportForm(forms.Form):
    desde = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Desde'
    )
    hasta = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label='Hasta'
    )

    def clean(self):
        cleaned_data = super().clean()
        desde = cleaned_data.get('desde')
        hasta = cleaned_data.get('hasta')
        hoy = timezone.localdate()

        if hasta and hasta > hoy:
            raise forms.ValidationError({
                'hasta': 'La fecha "Hasta" no puede ser posterior a hoy.'
            })

        if desde and hasta and desde > hasta:
            raise forms.ValidationError({
                'desde': 'La fecha "Desde" debe ser anterior o igual a la fecha "Hasta".'
            })

        return cleaned_data