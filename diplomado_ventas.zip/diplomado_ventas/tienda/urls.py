from django.urls import path
from . import views


urlpatterns = [
    path("", views.landing, name="landing"),
    path("acerca-de/", views.acerca_de, name="acerca_de"),
    path("preguntas-frecuentes/", views.faq, name="faq"),
    

    path("login/", views.login_view, name="login"),
    path("register/", views.register, name="register"),
    path("logout/", views.logout_view, name="logout"),

    # Productos
    path("productos/", views.productos_lista, name="productos_lista"),
    path("productos/<slug:slug>/", views.producto_detalle, name="producto_detalle"),
    # Reservas
    path("reservar/<slug:slug>/", views.reservar_producto, name="reservar_producto"),
    path("mis-reservas/", views.mis_reservas, name="mis_reservas"),
    # Panel vendedor
    path("vendedor/reservas-pendientes/", views.reservas_pendientes, name="reservas_pendientes"),
    path("vendedor/reservas-confirmadas/", views.reservas_confirmadas, name="reservas_confirmadas"),
    path("vendedor/reservas/<int:reserva_id>/confirmar/", views.confirmar_pago, name="confirmar_pago"),
    path("vendedor/reservas/<int:reserva_id>/cancelar/", views.cancelar_reserva, name="cancelar_reserva"),
    # ----------------- ADMIN · Gestionar PRODUCTOS -----------------
    path("panel-admin/productos/", views.admin_productos_list, name="admin_productos_list"),
    path("panel-admin/productos/nuevo/", views.admin_producto_crear, name="admin_producto_crear"),
    path("panel-admin/productos/<int:pk>/editar/", views.admin_producto_editar, name="admin_producto_editar"),
    
    path("panel-admin/productos/<int:pk>/archivar/", views.admin_producto_archivar, name="admin_producto_archivar"),
    path("panel-admin/productos/<int:pk>/activar/",  views.admin_producto_activar,  name="admin_producto_activar"),
    path("panel-admin/productos/<int:pk>/eliminar/", views.admin_producto_eliminar, name="admin_producto_eliminar"),

    # --------------- VENDEDOR · EDICIÓN LIMITADA ----------
    path("vendedor/productos/", views.vendedor_productos, name="vendedor_productos"),
    path("vendedor/productos/<int:pk>/editar/", views.vendedor_producto_editar, name="vendedor_producto_editar"),
    path("vendedor/productos/<int:pk>/imagenes/", views.vendedor_producto_imagenes, name="vendedor_producto_imagenes"),
    path("vendedor/ventas/nueva/", views.vendedor_venta_nueva, name="vendedor_venta_nueva"),

    # Admin (frontend)
    path("panel-admin/dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("panel-admin/usuarios/", views.admin_usuarios_list, name="admin_usuarios_list"),
    path("panel-admin/usuarios/<int:user_id>/toggle/", views.admin_usuario_toggle_activo, name="admin_usuario_toggle_activo"),
    path("panel-admin/usuarios/<int:user_id>/rol/", views.admin_usuario_cambiar_rol, name="admin_usuario_cambiar_rol"),

    path("panel-admin/reportes/", views.admin_reportes, name="admin_reportes"),
    path("panel-admin/reportes/csv/", views.admin_reportes_csv, name="admin_reportes_csv"),

    # Categorías (admin)
    path("panel-admin/categorias/", views.admin_categorias, name="admin_categorias"),
    path("panel-admin/categorias/<int:pk>/editar/", views.categoria_edit, name="categoria_edit"),
    path("panel-admin/categorias/<int:pk>/eliminar/", views.categoria_delete, name="categoria_delete"),


    path("panel-admin/reservas/", views.admin_reservas, name="admin_reservas"),

    # Ventas
    path("vendedor/ventas/", views.ventas_vendedor, name="ventas_vendedor"),
    path("panel-admin/ventas/", views.ventas_admin, name="ventas_admin"),
    path("mis-compras/", views.mis_compras, name="mis_compras"),
    #reseñas
    path("producto/<int:producto_id>/reseñar/", views.agregar_reseña, name="agregar_reseña"),

]
