from django.core.management.base import BaseCommand
from django.utils import timezone
from django.db import transaction
from datetime import timedelta

from tienda.models import Reserva, Usuario

PENALIZACION_EXPIRADAS = 3       # umbral de expiradas
PENALIZACION_DIAS_BLOQUEO = 7    # días de bloqueo

class Command(BaseCommand):
    help = "Marca como expirada toda reserva pendiente vencida y aplica bloqueos si corresponde."

    @transaction.atomic
    def handle(self, *args, **options):
        ahora = timezone.now()

        # 1) Expirar reservas pendientes vencidas
        vencidas = Reserva.objects.select_related("cliente").filter(
            estado="pendiente",
            fecha_vencimiento__lt=ahora
        )

        count_expiradas = 0
        afectados = set()

        for r in vencidas:
            r.estado = "expirada"
            r.save(update_fields=["estado"])
            count_expiradas += 1
            afectados.add(r.cliente_id)

        # 2) Penalizar clientes con demasiadas expiradas en últimos 30 días
        hace_30 = ahora - timedelta(days=30)
        bloqueados = 0

        for user_id in afectados:
            u = Usuario.objects.get(id=user_id)
            expiradas_ult_30 = u.reservas.filter(
                estado="expirada",
                fecha_reserva__gte=hace_30
            ).count()

            if expiradas_ult_30 >= PENALIZACION_EXPIRADAS:
                nuevo_bloqueo = ahora + timedelta(days=PENALIZACION_DIAS_BLOQUEO)
                # Solo ampliar si no está ya bloqueado o si el nuevo bloqueo es mayor
                if not u.bloqueado_hasta or u.bloqueado_hasta < nuevo_bloqueo:
                    u.bloqueado_hasta = nuevo_bloqueo
                    u.save(update_fields=["bloqueado_hasta"])
                    bloqueados += 1

        self.stdout.write(self.style.SUCCESS(
            f"Reservas expiradas: {count_expiradas}. Usuarios bloqueados/actualizados: {bloqueados}."
        ))
